#!/bin/bash
java -jar Path-Scan.jar $0